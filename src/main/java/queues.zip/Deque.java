import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Created by allenc289 on 9/27/14.
 */
public class Deque<Item> implements Iterable<Item> {
    private class Node<Item> {
        private Item item;
        private Node nextNode;
        private Node priorNode;

        public Node(Item item, Node next, Node prior) {
            this.item = item;
            this.nextNode = next;
            this.priorNode = prior;
        }

        public Item getItem() {
            return item;
        }

        public Node getNext() {
            return nextNode;
        }

        public void setNext(Node next) {
            this.nextNode = next;
        }

        public Node getPrior() {
            return priorNode;
        }

        public void setPrior(Node prior) {
            this.priorNode = prior;
        }

        public void cleanReferences() {
            item = null;
            nextNode = null;
            priorNode = null;
        }
    }

    private Node firstNode;
    private Node lastNode;
    private int queueSize;

    // construct an empty deque
    public Deque() {
        assert check();
    }

    // is the deque empty?
    public boolean isEmpty() {
        return firstNode == null;
    }

    // return the number of items on the deque
    public int size() {
        return queueSize;
    }

    // insert the item at the front
    public void addFirst(Item item) {
        if (item == null) throw new NullPointerException();

        queueSize++;
        Node nodeToAdd = new Node(item, firstNode, prior(firstNode));
        if (firstNode != null) {
            firstNode.setPrior(nodeToAdd);
        }
        if (queueSize == 1) {
            lastNode = nodeToAdd;
        }
        firstNode = nodeToAdd;

        assert check();
    }

    // insert the item at the end
    public void addLast(Item item) {
        if (item == null) throw new NullPointerException();

        queueSize++;
        Node nodeToAdd = new Node(item, null, lastNode);

        if (lastNode != null) {
            lastNode.setNext(nodeToAdd);
        }
        if (queueSize == 1) {
            firstNode = nodeToAdd;
        }
        lastNode = nodeToAdd;
        assert check();
    }

    // delete and return the item at the front
    public Item removeFirst() {
        if (isEmpty()) throw new NoSuchElementException();

        queueSize--;
        Node nodeToRemove = firstNode;

        firstNode = nodeToRemove.getNext();
        if (firstNode != null) {
            firstNode.setPrior(null);
        }
        if (queueSize <= 1) {
            lastNode = firstNode;
        }

        Item item = (Item) nodeToRemove.getItem();
        nodeToRemove.cleanReferences();

        assert check();
        return item;
    }

    // delete and return the item at the end
    public Item removeLast() {
        if (isEmpty()) throw new NoSuchElementException();

        queueSize--;
        Node nodeToRemove = lastNode;

        lastNode = nodeToRemove.getPrior();
        if (lastNode != null) {
            lastNode.setNext(null);
        }
        if (queueSize <= 1) {
            firstNode = lastNode;
        }

        Item item = (Item) nodeToRemove.getItem();
        nodeToRemove.cleanReferences();

        assert check();
        return item;
    }

    // return an iterator over items in order from front to end
    public Iterator<Item> iterator() {
        return new DequeIterator<Item>(this.firstNode);
    }

    // unit testing
    public static void main(String[] args) {

    }

    private class DequeIterator<Item> implements Iterator<Item> {
        private Deque.Node currentNode;

        public DequeIterator(Node firstNode) {
            this.currentNode = firstNode;
        }

        @Override
        public boolean hasNext() {
            return currentNode != null;
        }

        @Override
        public Item next() {
            if (currentNode == null) throw new NoSuchElementException();

            Item item = (Item) currentNode.getItem();
            currentNode = currentNode.getNext();
            return item;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    private Node prior(Node node) {
        if (node != null)
            return node.getPrior();
        else
            return null;
    }

    // check internal invariants
    private boolean check() {
        if (queueSize == 0) {
            if (firstNode != null) return false;
        }
        else if (queueSize == 1) {
            if (firstNode == null)      return false;
            if (firstNode.getNext() != null) return false;
        }
        else {
            if (firstNode.getNext() == null) return false;
        }

        // check internal consistency of instance variable N
        int numberOfNodes = 0;
        for (Node x = firstNode; x != null; x = x.getNext()) {
            numberOfNodes++;
        }
        if (numberOfNodes != queueSize) return false;

        return true;
    }
}
