import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;

/**
 * Created by allenc289 on 10/5/14.
 */
public class Fast {
    private static final int MINIMUM_SEGMENT_SIZE = 4;

    public static void main(String[] args) {
        Point[] points = getPoints(args[0]);
        ArrayList<LineSegment> lineSegments = getLineSegments(points);

        drawPoints(points);
        drawLineSegments(lineSegments);
    }

    private static ArrayList<LineSegment> getLineSegments(Point[] points) {
        //Think of p as the origin.
        //For each other point q, determine the slope it makes with p.
        //Sort the points according to the slopes they make with p.
        //Check if any 3 (or more) adjacent points in the sorted order have equal slopes with respect to p.
        // If so, these points, together with p, are collinear
        ArrayList<LineSegment> lineSegments = new ArrayList<LineSegment>();
        for (int i = 0; i < points.length - 1; i++) {
            ArrayList<Point> lineSegmentPoints = new ArrayList<Point>();

            Arrays.sort(points, i + 1, points.length, points[i].SLOPE_ORDER);

            int currentPosition = i + 1;
            double currentSlope = Double.NaN;
            while (currentPosition < points.length) {
                double thisSlope = points[i].slopeTo(points[currentPosition]);
                if (thisSlope == currentSlope) {
                    lineSegmentPoints.add(points[currentPosition]);
                } else {
                    addToLineSegmentArray(lineSegments, lineSegmentPoints, currentSlope);

                    currentSlope = thisSlope;
                    lineSegmentPoints.clear();
                    lineSegmentPoints.add(points[i]);
                    lineSegmentPoints.add(points[currentPosition]);
                }

                currentPosition++;
            }
            addToLineSegmentArray(lineSegments, lineSegmentPoints, currentSlope);
        }
        return lineSegments;
    }

    private static void addToLineSegmentArray(ArrayList<LineSegment> lineSegments, ArrayList<Point> lineSegmentPoints, double slope) {
        if (lineSegmentPoints.size() >= MINIMUM_SEGMENT_SIZE) {
            LineSegment lineSegmentToAdd = new LineSegment((Point[]) lineSegmentPoints.toArray(new Point[0]), slope);

            for (LineSegment lineSegment : lineSegments) {
                if (lineSegment.contains(lineSegmentToAdd)) return;
            }

            lineSegments.add(lineSegmentToAdd);
        }
    }

    private static void drawLineSegments(ArrayList<LineSegment> lineSegments) {
        for (LineSegment lineSegment : lineSegments) {
            ((Point) lineSegment.getPoints()[0]).drawTo((Point) lineSegment.getPoints()[lineSegment.getPoints().length - 1]);

            StdOut.println(lineSegment.toString());
        }
        StdDraw.show();

    }

    private static void drawPoints(Point[] points) {
        StdDraw.show(0);
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.setPenColor(StdDraw.BLACK);

        for (Point point : points) {
            point.draw();
        }
        StdDraw.show(0);
    }

    private static Point[] getPoints(String arg) {
        In in = new In(arg);      // input file
        int N = in.readInt();
        Point[] points = new Point[N];
        int pointNr = 0;

        while (!in.isEmpty()) {
            int x = in.readInt();
            int y = in.readInt();

            points[pointNr++] = new Point(x, y);
        }
        return points;
    }

    private static class LineSegment {
        private Point[] lineSegmentPoints;
        private double slope;

        private LineSegment(Point[] points, double lineSlope) {
            lineSegmentPoints = points;
            Arrays.sort(lineSegmentPoints);

            slope = lineSlope;
        }

        private boolean contains(LineSegment that) {
            if (slope != that.slope) return false;
            if (that.getPoints().length >= this.getPoints().length) return false;

            int thatPosition = 0;
            int thisPosition = 0;

            while (thisPosition < getPoints().length
                    && thatPosition < that.getPoints().length
                    && (getPoints().length - thisPosition >= that.getPoints().length - thatPosition)) {
                if (getPoints()[thisPosition].compareTo(that.getPoints()[thatPosition]) == 0) {
                    thatPosition++;
                }
                thisPosition++;
            }
            return thatPosition == that.getPoints().length;
        }

        private Point[] getPoints() {
            return lineSegmentPoints;
        }

        @Override
        public String toString() {
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < getPoints().length; i++) {
                sb.append(getPoints()[i].toString());
                if (i != getPoints().length - 1) {
                    sb.append(" -> ");
                }
            }

            return sb.toString();
        }
    }
}



/*
(10000, 0) -> (8000, 2000) -> (2000, 8000) -> (0, 10000)
(10000, 0) -> (13000, 0) -> (20000, 0) -> (30000, 0)
(30000, 0) -> (20000, 10000) -> (10000, 20000) -> (0, 30000)
(13000, 0) -> (11000, 3000) -> (9000, 6000) -> (5000, 12000)

(10000, 0) -> (8000, 2000) -> (2000, 8000) -> (0, 10000)
(10000, 0) -> (13000, 0) -> (20000, 0) -> (30000, 0)
(13000, 0) -> (11000, 3000) -> (9000, 6000) -> (5000, 12000)
*(18000, 2000) -> (9000, 6000) -> (0, 10000)
*(30000, 0) -> (9000, 6000) -> (2000, 8000)
(30000, 0) -> (20000, 10000) -> (10000, 20000) -> (0, 30000)
*(20000, 0) -> (18000, 2000) -> (2000, 18000)
 */